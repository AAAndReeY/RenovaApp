package com.example.renovaapp.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.renovaapp.R;

public class RegistroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);


        Button btnContinuar = findViewById(R.id.regBtnContinuar);


        btnContinuar.setOnClickListener(v -> {
            Intent intent = new Intent(RegistroActivity.this, GeneroActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
