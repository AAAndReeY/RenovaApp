package com.example.renovaapp.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.renovaapp.R;

public class MenuActivity extends AppCompatActivity {

    private Button btnmenuPerfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);

        btnmenuPerfil = findViewById(R.id.btnmenuPerfil);

        btnmenuPerfil.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, Preferencias.class);
            startActivity(intent);
        });

        Button btnNutricion = findViewById(R.id.nutricionButton);
        btnNutricion.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, NutricionActivity.class);
            startActivity(intent);
        });

    }
}