package com.example.renovaapp.actividades;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.renovaapp.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Preferencias extends AppCompatActivity {

    TextView tvAltura, tvPesoActual, tvIMC, tvHistorial;
    EditText etPesoNuevo;
    Button btnGuardarPeso;
    SharedPreferences prefs;
    Button btnVolver;
    float altura = 1.70f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferencias);

        tvAltura = findViewById(R.id.tvAltura);
        tvPesoActual = findViewById(R.id.tvPesoActual);
        tvIMC = findViewById(R.id.tvIMC);
        tvHistorial = findViewById(R.id.tvHistorial);
        etPesoNuevo = findViewById(R.id.etPesoNuevo);
        btnGuardarPeso = findViewById(R.id.btnGuardarPeso);

        prefs = getSharedPreferences("MiAppPrefs", MODE_PRIVATE);

        float peso = prefs.getFloat("peso", 75.0f);
        String historial = prefs.getString("historial", "");

        mostrarDatos(peso, historial);

        btnGuardarPeso.setOnClickListener(v -> {
            String pesoStr = etPesoNuevo.getText().toString();
            if (!pesoStr.isEmpty()) {
                float nuevoPeso = Float.parseFloat(pesoStr);

                SharedPreferences.Editor editor = prefs.edit();
                editor.putFloat("peso", nuevoPeso);

                String fecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
                String nuevoHistorial = fecha + ": " + nuevoPeso + " kg\n" + historial;
                editor.putString("historial", nuevoHistorial);

                editor.apply();

                mostrarDatos(nuevoPeso, nuevoHistorial);
                etPesoNuevo.setText("");
                Toast.makeText(this, "Peso actualizado", Toast.LENGTH_SHORT).show();
            }
        });

        btnVolver = findViewById(R.id.btnVolver);

        btnVolver.setOnClickListener(v -> {
            Intent intent = new Intent(Preferencias.this, MenuActivity.class);
            startActivity(intent);
        });
    }

    private void mostrarDatos(float peso, String historial) {
        tvAltura.setText("170 cm");
        tvPesoActual.setText(peso + " kg");

        float imc = peso / (altura * altura);
        tvIMC.setText(String.format("%.1f", imc));

        tvHistorial.setText(historial);

    }
}