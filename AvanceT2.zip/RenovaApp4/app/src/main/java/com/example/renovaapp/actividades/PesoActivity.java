package com.example.renovaapp.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.renovaapp.R;
import com.google.android.material.button.MaterialButton;

public class PesoActivity extends AppCompatActivity {

    private SeekBar seekBarPeso;
    private TextView tvPeso;
    private MaterialButton btnRegistrarPeso;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peso);


        seekBarPeso = findViewById(R.id.seekBarPeso);
        tvPeso = findViewById(R.id.tvPeso);
        btnRegistrarPeso = findViewById(R.id.btnRegistrarPeso);


        seekBarPeso.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                tvPeso.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnRegistrarPeso.setOnClickListener(v -> {
            Intent intent = new Intent(PesoActivity.this, ContratoActivity.class);
            startActivity(intent);
        });

    }
}
