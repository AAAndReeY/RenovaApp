package com.example.renovaapp.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;
import androidx.appcompat.app.AppCompatActivity;
import com.example.renovaapp.R;

public class AlturaActivity extends AppCompatActivity {

    private SeekBar seekAltura;
    private TextView txtAlturaSeleccionada;
    private MaterialButton btnContinuarAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_altura);


        seekAltura = findViewById(R.id.seekAltura);
        txtAlturaSeleccionada = findViewById(R.id.txtAlturaSeleccionada);
        btnContinuarAltura = findViewById(R.id.btnContinuarAltura);


        actualizarTextoAltura(seekAltura.getProgress());

        seekAltura.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                actualizarTextoAltura(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        btnContinuarAltura.setOnClickListener(v -> {
            Intent intent = new Intent(AlturaActivity.this, PesoActivity.class);
            startActivity(intent);
        });
    }

    private void actualizarTextoAltura(int alturaCm) {
        float alturaMetros = alturaCm / 100f;
        txtAlturaSeleccionada.setText(String.format("%.2f m", alturaMetros));
    }
}
