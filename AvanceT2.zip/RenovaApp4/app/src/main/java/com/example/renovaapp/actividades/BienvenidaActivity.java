package com.example.renovaapp.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.example.renovaapp.R;

public class BienvenidaActivity extends AppCompatActivity {

    private Button btnContinuarCorreo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bienvenida);

        btnContinuarCorreo = findViewById(R.id.btnContinuarCorreo);

        btnContinuarCorreo.setOnClickListener(v -> {
            Intent intent = new Intent(BienvenidaActivity.this, MenuActivity.class);
            startActivity(intent);
        });

    }
}