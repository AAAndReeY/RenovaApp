package com.example.renovaapp.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;
import androidx.appcompat.app.AppCompatActivity;
import com.example.renovaapp.R;

public class ContratoActivity extends AppCompatActivity {

    private ImageButton btncontrato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contrato);


        btncontrato = findViewById(R.id.btncontrato);


        btncontrato.setOnClickListener(v -> {
            Intent intent = new Intent(ContratoActivity.this, BienvenidaActivity.class );
            startActivity(intent);
        });
    }
}